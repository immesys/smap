response = {
    "status": "301",
    "version": (1, 1),
    "headers": [
    ],
    "body": ""
}
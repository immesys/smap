response = {
    "status": "404 Not Found",
    "version": (1, 1),
    "headers": [
    ],
    "body": ""
}
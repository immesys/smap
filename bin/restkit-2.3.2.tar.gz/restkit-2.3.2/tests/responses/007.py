response = {
    "status": "200 OK",
    "version": (1, 1),
    "headers": [
        ('Content-Type', 'text/html; charset=UTF-8'),
        ('Content-Length', '11'),
        ('Proxy-Connection', 'close'),
        ('Date', 'Thu, 31 Dec 2009 20:55:48 +0000'),
    ],
    "body": "hello world"
}
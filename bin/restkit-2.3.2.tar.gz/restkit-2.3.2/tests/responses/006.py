response = {
    "status": "200 OK",
    "version": (1, 1),
    "headers": [
        ('Content-Type', 'text/html; charset=utf-8'),
        ('Content-Length', '51'),
        ('Connection', 'close'),
    ],
    "body": "these headers are from http://news.ycombinator.com/"
}
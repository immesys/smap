response = {
    "status": "200 OK",
    "version": (1, 1),
    "headers": [
        ('Date', 'Tue, 04 Aug 2009 07:59:32 GMT'),
        ('Server', 'Apache'),
        ('X-Powered-By', 'Servlet/2.5 JSP/2.1'),
        ('Content-Type', 'text/xml; charset=utf-8'),
        ('Connection', 'close')
    ],
    "body": """<?xml version="1.0" encoding="UTF-8"?><SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">  <SOAP-ENV:Body>    <SOAP-ENV:Fault>       <faultcode>SOAP-ENV:Client</faultcode>       <faultstring>Client Error</faultstring>    </SOAP-ENV:Fault>  </SOAP-ENV:Body></SOAP-ENV:Envelope>"""

}
response = {
    "status": "200 OK",
    "version": (1, 1),
    "headers": [
        ('Content-Type', 'text/plain'),
        ('Transfer-Encoding', 'chunked'),
    ],
    "body": "  This is the data in the first chunk  and this is the second one"
}
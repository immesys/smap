from restkit.errors import InvalidRequestMethod
request = InvalidRequestMethod
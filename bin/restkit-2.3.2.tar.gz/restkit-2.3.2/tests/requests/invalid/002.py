from restkit.errors import InvalidRequestLine
request = InvalidRequestLine
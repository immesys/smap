from restkit.errors import InvalidHTTPVersion
request = InvalidHTTPVersion
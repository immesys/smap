from restkit.errors import InvalidHeaderName
request = InvalidHeaderName
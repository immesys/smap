from restkit.errors import NoMoreData
request = NoMoreData
request = {
    "method": "GET",
    "uri": uri("/test"),
    "version": (1, 0),
    "headers": [
        ("Host", "0.0.0.0:5000"),
        ("User-Agent", "ApacheBench/2.3"),
        ("Accept", "*/*")
    ],
    "body": ""
}